package com.jm.genich.bootfirst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
