package com.jm.genich.bootfirst.controllers;

import com.jm.genich.bootfirst.models.User;
import com.jm.genich.bootfirst.service.RoleServiceImpl;
import com.jm.genich.bootfirst.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.stream.Collectors;

@Controller
public class UsersController {
    @Autowired
    private UserService userService;


    //    @PostMapping(value = "/user")
//    public String saveChanges(@RequestParam Long id) {
//        userService.updateUser(id);
//        return "redirect:/admin";
//    }
    @PostMapping(value = "/save")
    public String saveChanges(@ModelAttribute User user, HttpServletRequest request, Model model) {
        userService.updateUser(user);
//        if (request.getParameterMap().containsKey("saved")) {
            model.addAttribute("saved", true);
            return "user";
        }
//        attributes.addAttribute("saved", null);
//        return "redirect:/user?saved";
//    }

    @GetMapping(value = "/user")
    public String showUserDetails(Model model, @RequestParam(required = false) Long id, @RequestParam(required = false) String hz, HttpServletRequest request,
                                  Authentication authentication, RedirectAttributes ra) {

        User currentUser = (User) authentication.getPrincipal();
        if (request.isUserInRole("ROLE_ADMIN")) {
            ra.addAttribute("id", currentUser.getId());

            return "redirect:/user";
        }

        User user = userService.getUser(id);
        model.addAttribute("user", user);
        model.addAttribute("role", new RoleServiceImpl());
        model.addAttribute("stringRoleList", user.getRoles().stream().map(t -> t.toString()).collect(Collectors.toList()));

        return "user";
    }

    @GetMapping(value = "/")
    public String justRedirect() {
        return "redirect:/users";
    }
}




