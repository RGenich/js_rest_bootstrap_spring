package com.jm.genich.bootfirst.models;

public enum Sex {
    MALE("male"), FEMALE("female");
    String sex;

    Sex(String s) {
        this.sex = s;
    }
}
